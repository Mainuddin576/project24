# Simple MERN To-Do

- MongoDB + Mongoose: stores tasks
- Express + Node: `server.js` (API + serves the page)
- React: loaded from a CDN in `public/index.html` (no build step)
- CSS: `public/style.css`

## Run

1. Install Node.js and start MongoDB locally (or set `MONGO_URI` to an Atlas string).
2. In this folder:

```bash
npm install
npm start
```

3. Open http://localhost:5000

Click a task to mark it done, click `x` to delete it.

const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());
app.use(express.static("public")); // serves the React page

// Model
const Todo = mongoose.model(
  "Todo",
  new mongoose.Schema({
    text: { type: String, required: true },
    done: { type: Boolean, default: false },
  })
);

// Routes
app.get("/api/todos", async (req, res) => res.json(await Todo.find()));

app.post("/api/todos", async (req, res) =>
  res.json(await Todo.create({ text: req.body.text }))
);

app.put("/api/todos/:id", async (req, res) =>
  res.json(await Todo.findByIdAndUpdate(req.params.id, req.body, { new: true }))
);

app.delete("/api/todos/:id", async (req, res) => {
  await Todo.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

// Start
mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/simple-mern")
  .then(() => app.listen(5000, () => console.log("Open http://localhost:5000")))
  .catch((err) => console.error("MongoDB error:", err.message));
